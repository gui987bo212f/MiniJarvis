"""Local console for Jarvis. The ESP32 cannot request host actions."""

import argparse
import array
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
import wave

import serial
from serial.tools import list_ports


JARVIS_COMMANDS = {
    "status": "STATUS",
    "sleep": "SLEEP",
    "wake": "WAKE",
}
COMMANDS_HELP = ("Commands: status, sleep, wake, sync, record, photo, "
                 "say <text>, open, quit")
AUDIO_RATE = 16000
AUDIO_BYTES = AUDIO_RATE * 2 * 2  # 2 seconds, mono, 16-bit PCM
PLAY_CHUNK = 2048                  # must match PLAY_CHUNK in the firmware
MAX_JPEG_BYTES = 200_000
MAX_SPEECH_SECONDS = 35            # firmware accepts up to 1,200,000 bytes


def read_jarvis_line(port, timeout):
    deadline = time.monotonic() + timeout
    pending = bytearray()
    oversized = False
    while time.monotonic() < deadline:
        chunk = port.read_until(b"\n", size=256)
        if not oversized:
            pending.extend(chunk)
            oversized = len(pending) > 256
        if chunk.endswith(b"\n"):
            if not oversized and pending.startswith(b"JARVIS "):
                message = bytes(pending[7:]).rstrip(b"\r\n")
                if message and all(32 <= byte <= 126 for byte in message):
                    return message
            pending.clear()
            oversized = False
    return None


def quiet_command(port, command):
    """Send a command and wait for its reply, without printing it."""
    port.reset_input_buffer()
    port.write((command + "\n").encode("ascii"))
    return read_jarvis_line(port, 2.5)


def send_jarvis_command(port, command):
    """A serial response is display text only, never a host instruction."""
    message = quiet_command(port, command)
    if message is None:
        print("No Jarvis reply. Check the port, firmware, and whether a serial monitor is open.")
    else:
        print(message.decode("ascii"))


def sync_time(port, attempts=3):
    """Give the desk clock the PC's local time (seconds since local midnight)."""
    for _ in range(attempts):
        now = time.localtime()
        seconds = now.tm_hour * 3600 + now.tm_min * 60 + now.tm_sec
        reply = quiet_command(port, f"TIME {seconds}")
        if reply is not None and reply.startswith(b"state="):
            return True
    return False


def capture_pcm(port):
    """Request one 2 s clip. Returns PCM bytes, or None / an error string."""
    port.reset_input_buffer()
    port.write(b"RECORD\n")
    header = read_jarvis_line(port, 10)
    if header != f"AUDIO {AUDIO_BYTES}".encode("ascii"):
        return header.decode("ascii") if header and header.startswith(b"ERR ") else None

    pcm = bytearray()
    deadline = time.monotonic() + 12
    while time.monotonic() < deadline:
        pcm.extend(port.read(min(4096, AUDIO_BYTES - len(pcm))))
        if len(pcm) == AUDIO_BYTES:
            return bytes(pcm)
    return None


def capture_jpeg(port):
    """Ask the Sense camera for one JPEG. Returns bytes, or None on any failure."""
    port.reset_input_buffer()
    port.write(b"SNAP\n")
    header = read_jarvis_line(port, 10)
    if not header or not header.startswith(b"IMAGE "):
        return None
    try:
        size = int(header[6:])
    except ValueError:
        return None
    if not 0 < size <= MAX_JPEG_BYTES:
        return None
    data = bytearray()
    deadline = time.monotonic() + 15
    while len(data) < size and time.monotonic() < deadline:
        data.extend(port.read(min(4096, size - len(data))))
    if len(data) != size or data[:2] != b"\xff\xd8":
        return None
    return bytes(data)


def save_unique(prefix, suffix, data):
    """Write data to a new file in the current folder; never overwrite."""
    path = Path(f"{prefix}-{time.time_ns()}{suffix}")
    try:
        with path.open("xb") as handle:
            handle.write(data)
    except OSError as error:
        try:
            path.unlink()
        except OSError:
            pass
        raise error
    return path


def record_audio(port):
    """Request one local clip; do not save partial transfers."""
    print("Recording two seconds from the Jarvis microphone...")
    pcm = capture_pcm(port)
    if pcm is None or isinstance(pcm, str):
        detail = pcm if isinstance(pcm, str) else "no valid audio reply"
        print(f"Recording failed: {detail}.")
        return

    path = Path(f"jarvis-{time.time_ns()}.wav")
    created = False
    try:
        with path.open("xb") as raw:
            created = True
            with wave.open(raw, "wb") as clip:
                clip.setnchannels(1)
                clip.setsampwidth(2)
                clip.setframerate(AUDIO_RATE)
                clip.writeframes(pcm)
    except (OSError, wave.Error) as error:
        if created:
            try:
                path.unlink()
            except OSError:
                pass
        print(f"Could not save WAV: {error}")
        return
    print(f"Saved {path.absolute()}")


def take_photo(port):
    print("Taking a photo with the Jarvis camera...")
    jpeg = capture_jpeg(port)
    if jpeg is None:
        print("Photo failed: no valid image reply.")
        return
    try:
        path = save_unique("jarvis", ".jpg", jpeg)
    except OSError as error:
        print(f"Could not save JPEG: {error}")
        return
    print(f"Saved {path.absolute()}")


# ---------------------------------------------------------------- PC speakers

def speech_command(text_file):
    """Select an offline OS voice; the spoken text is data, never command text."""
    if sys.platform == "darwin":
        return ["/usr/bin/say", "-f", str(text_file)]
    if sys.platform == "win32":
        powershell = shutil.which("powershell.exe")
        if not powershell:
            raise OSError("Windows PowerShell is required for the system voice.")
        script = (
            "[Console]::InputEncoding = [Text.Encoding]::UTF8; "
            "$ErrorActionPreference = 'Stop'; "
            "Add-Type -AssemblyName System.Speech; "
            "$voice = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
            "try { $voice.Speak([Console]::In.ReadToEnd()) } finally { $voice.Dispose() }"
        )
        return [powershell, "-NoProfile", "-NonInteractive", "-Command", script]
    if sys.platform.startswith("linux"):
        voice = shutil.which("espeak-ng") or shutil.which("espeak")
        if not voice:
            raise OSError("Install eSpeak NG to enable the system voice on Linux.")
        return [voice, "-b", "1", "--stdin"]
    raise OSError("Speech is supported on Windows, macOS, and Linux.")


def speak_on_pc(port, text):
    """Animate while local playback is alive; the device cannot trigger speech."""
    if not text or len(text) > 500:
        print("Use say followed by 1–500 characters of text.")
        return
    try:
        with tempfile.TemporaryDirectory(prefix="jarvis-voice-") as folder:
            text_file = Path(folder) / "speech.txt"
            text_file.write_text(text, encoding="utf-8")
            args = speech_command(text_file)
            with text_file.open("rb") as source:
                port.write(b"TALK\n")
                try:
                    with subprocess.Popen(args, shell=False, stdin=source,
                                          stdout=subprocess.DEVNULL,
                                          stderr=subprocess.DEVNULL) as voice:
                        try:
                            while True:
                                try:
                                    code = voice.wait(timeout=0.5)
                                except subprocess.TimeoutExpired:
                                    port.write(b"TALK\n")
                                    continue
                                if code != 0:
                                    print("The system voice could not play the text.")
                                break
                        finally:
                            if voice.poll() is None:
                                voice.kill()
                finally:
                    port.write(b"QUIET\n")
    except serial.SerialException:
        raise
    except OSError as error:
        print(f"Speech unavailable: {error}")


# ------------------------------------------------------- Jarvis speaker (I2S)

def to_device_pcm(wav_path):
    """Read a PCM WAV and return mono 16-bit little-endian samples at 16 kHz."""
    with wave.open(str(wav_path), "rb") as clip:
        channels = clip.getnchannels()
        width = clip.getsampwidth()
        rate = clip.getframerate()
        frames = clip.readframes(clip.getnframes())
    if width != 2 or channels not in (1, 2) or rate <= 0:
        raise OSError("The system voice produced an unsupported WAV format.")

    samples = array.array("h")
    samples.frombytes(frames[: len(frames) - len(frames) % (2 * channels)])
    if sys.byteorder == "big":
        samples.byteswap()
    if channels == 2:
        samples = array.array("h", ((samples[i] + samples[i + 1]) // 2
                                    for i in range(0, len(samples) - 1, 2)))
    if rate != AUDIO_RATE:
        count = int(len(samples) * AUDIO_RATE / rate)
        step = rate / AUDIO_RATE
        out = array.array("h")
        last = len(samples) - 1
        for n in range(count):
            position = n * step
            index = int(position)
            if index >= last:
                out.append(samples[last])
                continue
            fraction = position - index
            out.append(int(samples[index] * (1 - fraction) + samples[index + 1] * fraction))
        samples = out
    if sys.byteorder == "big":
        samples.byteswap()
    return samples.tobytes()


def synthesize_pcm(text):
    """Offline text-to-speech into device PCM. The text is data, never command text."""
    with tempfile.TemporaryDirectory(prefix="jarvis-voice-") as folder:
        text_file = Path(folder) / "speech.txt"
        wav_file = Path(folder) / "speech.wav"
        text_file.write_text(text, encoding="utf-8")

        if sys.platform == "darwin":
            args = ["/usr/bin/say", "-f", str(text_file), "-o", str(wav_file),
                    "--data-format=LEI16@16000"]
            result = subprocess.run(args, shell=False, stdin=subprocess.DEVNULL,
                                    capture_output=True, timeout=60)
        elif sys.platform == "win32":
            powershell = shutil.which("powershell.exe")
            if not powershell:
                raise OSError("Windows PowerShell is required for the system voice.")
            script = (
                "[Console]::InputEncoding = [Text.Encoding]::UTF8; "
                "$ErrorActionPreference = 'Stop'; "
                "Add-Type -AssemblyName System.Speech; "
                "$voice = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                "try { "
                "$format = New-Object System.Speech.AudioFormat.SpeechAudioFormatInfo("
                "16000, [System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen, "
                "[System.Speech.AudioFormat.AudioChannel]::Mono); "
                "$voice.SetOutputToWaveFile($env:JARVIS_WAV, $format); "
                "$voice.Speak([Console]::In.ReadToEnd()) "
                "} finally { $voice.Dispose() }"
            )
            env = dict(os.environ, JARVIS_WAV=str(wav_file))
            result = subprocess.run(
                [powershell, "-NoProfile", "-NonInteractive", "-Command", script],
                shell=False, input=text.encode("utf-8"), capture_output=True,
                env=env, timeout=60)
        elif sys.platform.startswith("linux"):
            voice = shutil.which("espeak-ng") or shutil.which("espeak")
            if not voice:
                raise OSError("Install eSpeak NG to enable the system voice on Linux.")
            with text_file.open("rb") as source:
                result = subprocess.run([voice, "-b", "1", "--stdin", "--stdout"],
                                        shell=False, stdin=source,
                                        capture_output=True, timeout=60)
            if result.returncode == 0:
                wav_file.write_bytes(result.stdout)
        else:
            raise OSError("Speech is supported on Windows, macOS, and Linux.")

        if result.returncode != 0 or not wav_file.exists():
            raise OSError("The system voice could not render the text.")
        pcm = to_device_pcm(wav_file)

    pcm = pcm[: len(pcm) - len(pcm) % 2]
    if len(pcm) < 2:
        raise OSError("The system voice produced no audio.")
    if len(pcm) > MAX_SPEECH_SECONDS * AUDIO_RATE * 2:
        raise OSError("The text is too long to speak.")
    return pcm


def play_pcm(port, pcm):
    """Stream PCM to the Jarvis speaker. One ACK per chunk keeps the device buffer safe."""
    port.reset_input_buffer()
    port.write(f"PLAY {len(pcm)}\n".encode("ascii"))
    ready = read_jarvis_line(port, 3)
    if ready != b"READY":
        detail = ready.decode("ascii") if ready and ready.startswith(b"ERR ") else "no reply"
        print(f"Jarvis speaker unavailable: {detail}.")
        return False
    for start in range(0, len(pcm), PLAY_CHUNK):
        port.write(pcm[start:start + PLAY_CHUNK])
        answer = read_jarvis_line(port, 5)
        if answer != b"ACK":
            detail = answer.decode("ascii") if answer else "no reply"
            print(f"Speaker transfer failed: {detail}.")
            return False
    return True


def speak(port, text):
    """Speak on the Jarvis speaker; fall back to the PC speakers if that is not possible."""
    if not text or len(text) > 500:
        print("Use say followed by 1–500 characters of text.")
        return
    try:
        pcm = synthesize_pcm(text)
    except (OSError, subprocess.SubprocessError, wave.Error, EOFError) as error:
        print(f"Could not prepare speech for the Jarvis speaker ({error}); using the PC.")
        speak_on_pc(port, text)
        return
    play_pcm(port, pcm)


# ------------------------------------------------------------------ open apps

def get_local_target(raw):
    raw = raw.strip()
    if len(raw) >= 2 and raw[0] == raw[-1] and raw[0] in "\"'":
        raw = raw[1:-1]
    if not raw:
        raise ValueError("Enter an absolute path or leave the prompt to cancel.")
    path = Path(raw).expanduser()
    if not path.is_absolute():
        raise ValueError("Use the full path to the app or folder.")
    path = path.resolve(strict=True)
    if sys.platform == "darwin" and path.is_dir() and path.suffix.lower() == ".app":
        return path, "app"
    if path.is_dir():
        return path, "folder"
    if sys.platform == "win32" and path.is_file() and path.suffix.lower() == ".exe":
        return path, "app"
    if sys.platform.startswith("linux") and path.is_file() and os.access(path, os.X_OK):
        return path, "app"
    raise ValueError("Choose a folder or an app (.exe on Windows, .app on macOS, executable on Linux).")


def dispatch(path, kind):
    target = str(path)
    if sys.platform == "win32":
        if kind == "folder":
            os.startfile(target)
            return
        arguments = [target]
    elif sys.platform == "darwin":
        arguments = ["/usr/bin/open", target]
    elif sys.platform.startswith("linux"):
        if kind == "folder":
            opener = shutil.which("xdg-open")
            if opener is None:
                raise OSError("Opening folders requires xdg-open on a Linux desktop.")
            arguments = [opener, target]
        else:
            arguments = [target]
    else:
        raise OSError("Opening apps and folders is supported on Windows, macOS, and Linux.")
    subprocess.Popen(arguments, shell=False, stdin=subprocess.DEVNULL,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def open_requested_target():
    raw = input("Full path to app or folder (blank cancels): ")
    if not raw.strip():
        return False
    try:
        path, kind = get_local_target(raw)
        print(f"Request to open {kind}: {str(path)!r}")
        if input("Type OPEN to approve this one request: ") != "OPEN":
            print("Cancelled.")
            return False
        dispatch(path, kind)
    except (OSError, RuntimeError, ValueError) as error:
        print(f"Open request failed: {error}")
        return False
    print("Open request sent to your operating system.")
    return True


def open_port(name):
    port = serial.Serial(baudrate=115200, timeout=0.2, write_timeout=5)
    port.port = name
    port.dtr = False
    port.rts = False
    return port


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("port", nargs="?", help="Jarvis USB serial port (e.g. COM5)")
    parser.add_argument("--list", action="store_true", help="List available serial ports")
    args = parser.parse_args()
    if args.list:
        for item in list_ports.comports():
            print(f"{item.device}: {item.description}")
        return 0
    if not args.port:
        parser.error("Supply a serial port or use --list to find it.")

    port = open_port(args.port)
    try:
        with port:
            time.sleep(0.3)  # the board may restart when the port opens
            if not sync_time(port):
                print("Could not sync the clock yet. Type sync once Jarvis has started.")
            print(COMMANDS_HELP)
            while True:
                fields = input("jarvis> ").strip().split(maxsplit=1)
                if not fields:
                    continue
                command = fields[0].lower()
                if command == "say":
                    speak(port, fields[1] if len(fields) > 1 else "")
                    continue
                if len(fields) != 1:
                    print(COMMANDS_HELP)
                    continue
                if command in {"quit", "exit"}:
                    break
                if command == "open":
                    if open_requested_target():
                        send_jarvis_command(port, "OPENED")
                elif command == "record":
                    record_audio(port)
                elif command == "photo":
                    take_photo(port)
                elif command == "sync":
                    print("Clock synced." if sync_time(port) else "No Jarvis reply.")
                elif command in JARVIS_COMMANDS:
                    send_jarvis_command(port, JARVIS_COMMANDS[command])
                else:
                    print(COMMANDS_HELP)
    except (EOFError, KeyboardInterrupt):
        print("\nDisconnected.")
    except serial.SerialException as error:
        print(f"Serial connection failed: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
