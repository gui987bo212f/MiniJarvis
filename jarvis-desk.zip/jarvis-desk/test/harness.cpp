// Runs the real firmware source on a PC. Serial = stdin/stdout. Env: JARVIS_TIME_SCALE, JARVIS_FB_OUT, JARVIS_SPK_OUT.
#include <Arduino.h>
#include <Adafruit_GC9A01A.h>
#include <SPI.h>
#include <driver/i2s.h>
#include <esp_camera.h>
#include <esp_timer.h>
#include <signal.h>
#include <sys/time.h>

HostSerial Serial;
SPIClass SPI;
uint16_t hostFrame[240 * 240];
void setup();
void loop();

static int64_t realUs() { timeval tv; gettimeofday(&tv, nullptr); return (int64_t)tv.tv_sec * 1000000 + tv.tv_usec; }
static int64_t startUs = realUs();
double hostScale() { static double s = getenv("JARVIS_TIME_SCALE") ? atof(getenv("JARVIS_TIME_SCALE")) : 1.0; return s; }
uint32_t millis() { return (uint32_t)(((realUs() - startUs) / 1000.0) * hostScale()); }
int64_t esp_timer_get_time() { return (int64_t)((realUs() - startUs) * hostScale()); }
void delay(uint32_t ms) { usleep((useconds_t)(ms * 1000.0 / hostScale())); }

static bool micOpen = false, spkOpen = false;
esp_err_t i2s_driver_install(i2s_port_t p, const i2s_config_t *c, int, void *) {
    if (p == I2S_NUM_0) { if (micOpen || !(c->mode & I2S_MODE_PDM) || !(c->mode & I2S_MODE_RX)) return 1; micOpen = true; }
    else { if (spkOpen || !(c->mode & I2S_MODE_TX)) return 1; spkOpen = true; }
    return ESP_OK;
}
esp_err_t i2s_set_pin(i2s_port_t, const i2s_pin_config_t *) { return ESP_OK; }
static uint32_t micPhase = 0;
esp_err_t i2s_read(i2s_port_t p, void *dst, size_t n, size_t *got, TickType_t) {
    if (p != I2S_NUM_0 || !micOpen) return 1;
    int16_t *s = (int16_t *)dst;
    for (size_t i = 0; i < n / 4; ++i, ++micPhase) {
        s[2 * i] = 5;  // idle slot: constant DC only
        s[2 * i + 1] = (int16_t)(1000 * sin(micPhase * 2 * M_PI / 40.0) + 50);  // microphone slot, with DC
    }
    *got = n;
    usleep((useconds_t)(n / 4 * 1000000.0 / 16000 / 4));  // faster than real time
    return ESP_OK;
}
esp_err_t i2s_write(i2s_port_t p, const void *src, size_t n, size_t *w, TickType_t) {
    if (p != I2S_NUM_1 || !spkOpen) return 1;
    if (const char *path = getenv("JARVIS_SPK_OUT")) { FILE *f = fopen(path, "ab"); fwrite(src, 1, n, f); fclose(f); }
    *w = n;
    return ESP_OK;
}
esp_err_t i2s_stop(i2s_port_t) { return ESP_OK; }
esp_err_t i2s_zero_dma_buffer(i2s_port_t) { return ESP_OK; }
esp_err_t i2s_driver_uninstall(i2s_port_t p) { (p == I2S_NUM_0 ? micOpen : spkOpen) = false; return ESP_OK; }

static bool camOpen = false;
static uint8_t jpeg[50000];
static camera_fb_t fb = {jpeg, sizeof(jpeg)};
esp_err_t esp_camera_init(const camera_config_t *c) {
    if (camOpen || c->pin_xclk != 10 || c->pin_sccb_sda != 40) return 1;
    for (size_t i = 0; i < sizeof(jpeg); ++i) jpeg[i] = (uint8_t)(i * 7);
    jpeg[0] = 0xFF; jpeg[1] = 0xD8; jpeg[sizeof(jpeg) - 2] = 0xFF; jpeg[sizeof(jpeg) - 1] = 0xD9;
    camOpen = true; return ESP_OK;
}
camera_fb_t *esp_camera_fb_get() { return camOpen ? &fb : nullptr; }
void esp_camera_fb_return(camera_fb_t *) {}
esp_err_t esp_camera_deinit() { camOpen = false; return ESP_OK; }

static volatile sig_atomic_t dumpRequested = 0;
static void onSignal(int) { dumpRequested = 1; }
int main() {
    signal(SIGUSR1, onSignal);
    setup();
    for (;;) {
        loop();
        if (dumpRequested) {
            dumpRequested = 0;
            FILE *f = fopen(getenv("JARVIS_FB_OUT") ? getenv("JARVIS_FB_OUT") : "/tmp/jarvis_fb.ppm", "wb");
            fprintf(f, "P6\n240 240\n255\n");
            for (int i = 0; i < 240 * 240; ++i) {
                uint16_t c = hostFrame[i];
                unsigned char px[3] = {(unsigned char)(((c >> 11) & 31) * 255 / 31), (unsigned char)(((c >> 5) & 63) * 255 / 63), (unsigned char)((c & 31) * 255 / 31)};
                fwrite(px, 1, 3, f);
            }
            fclose(f);
        }
    }
}
