import math, os, signal, struct, subprocess, sys, time
from PIL import Image
import jarvis_console as jc

FW = os.path.abspath("fw")
SPK = "/tmp/jarvis_spk.raw"
FB = "/tmp/jarvis_fb.ppm"
results = []

def check(name, cond, extra=""):
    results.append(cond)
    print(("PASS " if cond else "FAIL ") + name + (f"  [{extra}]" if extra and not cond else ""))

def open_fw(scale=None):
    for f in (SPK, FB):
        if os.path.exists(f): os.remove(f)
    os.environ["JARVIS_SPK_OUT"] = SPK
    os.environ["JARVIS_FB_OUT"] = FB
    if scale: os.environ["JARVIS_TIME_SCALE"] = str(scale)
    else: os.environ.pop("JARVIS_TIME_SCALE", None)
    p = jc.open_port(FW)
    p.open()
    time.sleep(0.2)
    return p

def dump(p, png=None):
    if os.path.exists(FB): os.remove(FB)
    os.kill(p.proc.pid, signal.SIGUSR1)
    for _ in range(100):
        if os.path.exists(FB) and os.path.getsize(FB) == 15 + 240*240*3: break
        time.sleep(0.02)
    time.sleep(0.05)
    im = Image.open(FB).convert("RGB")
    if png: im.resize((480, 480), Image.NEAREST).save(png)
    return im

# ---------------------------------------------------------------- protocol
p = open_fw()
check("sync_time", jc.sync_time(p))
r = jc.quiet_command(p, "STATUS")
check("STATUS -> HAPPY", r == b"state=HAPPY", r)
check("TIME junk ignored", jc.quiet_command(p, "TIME 99999") is None)
check("TIME letters ignored", jc.quiet_command(p, "TIME 12ab") is None)
p.write(b"\x01\xffgarbage\n" + b"X"*200 + b"\n" + b"STATUS" + b"Y"*30 + b"\n")
time.sleep(0.2)
check("survives junk/oversized lines", jc.quiet_command(p, "STATUS") == b"state=HAPPY")

pcm = jc.capture_pcm(p)
ok = isinstance(pcm, bytes) and len(pcm) == jc.AUDIO_BYTES
check("RECORD returns 64000 bytes", ok, type(pcm))
if ok:
    import array
    a = array.array("h"); a.frombytes(pcm)
    peak = max(a); low = min(a)
    check("mic slot auto-select + DC removal + gain", 3900 <= peak <= 4100 and -4100 <= low <= -3900, f"{peak},{low}")
jpeg = jc.capture_jpeg(p)
check("SNAP returns valid 50000-byte JPEG", jpeg is not None and len(jpeg) == 50000 and jpeg[-2:] == b"\xff\xd9")

def tone(n):
    return b"".join(struct.pack("<h", int(8000*math.sin(i*2*math.pi/50))) for i in range(n))
for n in (32000, 5000, 2048, 2, 4098):
    if os.path.exists(SPK): os.remove(SPK)
    data = tone(n//2)
    ok = jc.play_pcm(p, data)
    time.sleep(0.5)
    raw = open(SPK, "rb").read() if os.path.exists(SPK) else b""
    st = struct.unpack("<%dh" % (len(raw)//2), raw)
    mono_ok = len(raw) == 2*len(data) and all(st[2*i] == st[2*i+1] for i in range(len(st)//2))
    same = bytes(b"".join(struct.pack("<h", st[2*i]) for i in range(len(st)//2))) == data
    check(f"PLAY {n} bytes -> ack ok, stereo dup, data intact", ok and mono_ok and same, f"{len(raw)}")
r = jc.quiet_command(p, "PLAY 3")
check("PLAY odd length rejected", r == b"ERR bad_play", r)
p.reset_input_buffer(); p.write(b"PLAY 0\n"); time.sleep(0.1)
check("PLAY 0 rejected", jc.read_jarvis_line(p, 1) == b"ERR bad_play")
p.reset_input_buffer(); p.write(b"PLAY 99999999\n"); time.sleep(0.1)
check("PLAY too big rejected", jc.read_jarvis_line(p, 1) == b"ERR bad_play")
# after a failure the port still works
check("STATUS after play errors", jc.quiet_command(p, "STATUS") == b"state=HAPPY")

# PLAY timeout: promise bytes, never send them
p.reset_input_buffer(); p.write(b"PLAY 4096\n")
check("READY", jc.read_jarvis_line(p, 2) == b"READY")
t0 = time.time(); r = jc.read_jarvis_line(p, 6)
check("play_timeout reported after ~3 s", r == b"ERR play_timeout" and 2.5 < time.time()-t0 < 5, (r, time.time()-t0))
time.sleep(0.5)
check("recovers after timeout", jc.quiet_command(p, "STATUS") is not None)

# manual rest: clock face
jc.quiet_command(p, "TIME 36576")   # 10:09:36
r = jc.quiet_command(p, "SLEEP")
check("SLEEP -> ASLEEP", r == b"state=ASLEEP", r)
time.sleep(0.4)
im = dump(p, "/tmp/clock.png")
def near(c, t, tol=60): return all(abs(a-b) <= tol for a, b in zip(c, t))
def hand_present(angle, radius):
    x = 120 + radius*math.sin(math.radians(angle)); y = 120 - radius*math.cos(math.radians(angle))
    for dx in (-1,0,1):
        for dy in (-1,0,1):
            c = im.getpixel((int(round(x))+dx, int(round(y))+dy))
            if near(c, (78,239,255)) or near(c, (0,118,137), 30): return True
    return False
hour = (10 + 9/60 + 36/3600) * 30; minute = (9 + 36/60) * 6
check("hour hand at 10:09:36", hand_present(hour, 25) and hand_present(hour, 40), f"{hour:.1f}")
check("minute hand at 10:09:36", hand_present(minute, 40) and hand_present(minute, 60), f"{minute:.1f}")
check("no hand opposite the hour hand", not hand_present(hour+180, 40))
hits = []
for a in range(0, 360):
    for r in (60, 80):
        x = 120 + r*math.sin(math.radians(a)); y = 120 - r*math.cos(math.radians(a))
        if any(near(im.getpixel((int(round(x))+dx, int(round(y))+dy)), (255,124,86), 40) for dx in (-1,0,1) for dy in (-1,0,1)):
            hits.append(a)
check("second hand only near 216-230 deg", hits and min(hits) >= 210 and max(hits) <= 236, (min(hits), max(hits)) if hits else None)
jc.quiet_command(p, "WAKE")
time.sleep(0.4)
dump(p, "/tmp/idle_hud.png")
p.write(b"TALK\n"); time.sleep(0.3)
dump(p, "/tmp/talking.png")
check("STATUS while talking", jc.quiet_command(p, "STATUS") == b"state=TALKING")
p.close()

# ------------------------------------------------- 30 s inactivity -> rest
p = open_fw(scale=60)   # 1 real second = 60 virtual seconds
jc.sync_time(p)
jc.quiet_command(p, "WAKE")
time.sleep(0.25)        # ~15 s virtual
check("not resting after ~15 s", jc.quiet_command(p, "STATUS") == b"state=HAPPY")
time.sleep(0.4)         # total ~40 s virtual
check("resting after >30 s of inactivity", jc.quiet_command(p, "STATUS") == b"state=RESTING")
jc.quiet_command(p, "TIME 43200"); jc.quiet_command(p, "STATUS")
dump(p, "/tmp/auto_rest.png")
p.write(b"TALK\n"); time.sleep(0.1)   # talk overlay (30 ms virtual-hold) is already over
check("TALK counts as activity -> HUD, not clock", jc.quiet_command(p, "STATUS") == b"state=HAPPY")
time.sleep(0.7)
check("rests again after another 30 s", jc.quiet_command(p, "STATUS") == b"state=RESTING")
jc.quiet_command(p, "STATUS")
# STATUS and TIME must not count as activity
time.sleep(0.2)
jc.quiet_command(p, "TIME 100")
check("TIME does not wake", jc.quiet_command(p, "STATUS") == b"state=RESTING")
p.close()

print(f"\n{sum(results)}/{len(results)} passed")
sys.exit(0 if all(results) else 1)
