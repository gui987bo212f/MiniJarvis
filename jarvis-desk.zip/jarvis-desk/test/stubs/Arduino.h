#pragma once
// Host stand-in for the Arduino core, used only to compile and run the firmware on a PC.
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <deque>

#define INPUT 0
#define OUTPUT 1
typedef uint32_t TickType_t;
#define pdMS_TO_TICKS(ms) ((TickType_t)(ms))

double hostScale();
uint32_t millis();
void delay(uint32_t ms);
inline void pinMode(int, int) {}

struct HostSerial {
    std::deque<uint8_t> in;
    void fill() {
        uint8_t tmp[4096];
        ssize_t n = ::read(0, tmp, sizeof(tmp));
        if (n > 0) for (ssize_t i = 0; i < n; ++i) in.push_back(tmp[i]);
        else if (n == 0) _exit(0);
    }
    size_t setRxBufferSize(size_t s) { return s; }
    size_t setTxBufferSize(size_t s) { return s; }
    void begin(unsigned long) {
        fcntl(0, F_SETFL, fcntl(0, F_GETFL) | O_NONBLOCK);
    }
    int available() { fill(); return (int)in.size(); }
    int read() { fill(); if (in.empty()) return -1; int c = in.front(); in.pop_front(); return c; }
    size_t readBytes(char *buf, size_t n) {
        size_t i = 0;
        while (i < n && !in.empty()) { buf[i++] = (char)in.front(); in.pop_front(); }
        return i;
    }
    int availableForWrite() { return 4096; }
    size_t write(const uint8_t *b, size_t n) {
        size_t sent = 0;
        while (sent < n) {
            ssize_t w = ::write(1, b + sent, n - sent);
            if (w < 0) { usleep(100); continue; }
            sent += (size_t)w;
        }
        return n;
    }
    size_t print(const char *s) { return write((const uint8_t *)s, strlen(s)); }
    int printf(const char *fmt, ...) {
        char tmp[256];
        va_list ap; va_start(ap, fmt);
        int n = vsnprintf(tmp, sizeof(tmp), fmt, ap);
        va_end(ap);
        write((const uint8_t *)tmp, (size_t)n);
        return n;
    }
};
extern HostSerial Serial;
