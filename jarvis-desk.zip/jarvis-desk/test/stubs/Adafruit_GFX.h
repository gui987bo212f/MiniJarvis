#pragma once
// Minimal software rasteriser with the same method names as Adafruit_GFX's GFXcanvas16.
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
class GFXcanvas16 {
public:
    GFXcanvas16(int w, int h) : W(w), H(h), buf((uint16_t *)calloc(w * h, 2)) {}
    uint16_t *getBuffer() { return buf; }
    void drawPixel(int x, int y, uint16_t c) { if (x >= 0 && y >= 0 && x < W && y < H) buf[y * W + x] = c; }
    void fillScreen(uint16_t c) { for (int i = 0; i < W * H; ++i) buf[i] = c; }
    void drawLine(int x0, int y0, int x1, int y1, uint16_t c) {
        int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1, dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1, err = dx + dy;
        for (;;) {
            drawPixel(x0, y0, c);
            if (x0 == x1 && y0 == y1) break;
            int e2 = 2 * err;
            if (e2 >= dy) { err += dy; x0 += sx; }
            if (e2 <= dx) { err += dx; y0 += sy; }
        }
    }
    void fillRect(int x, int y, int w, int h, uint16_t c) { for (int j = 0; j < h; ++j) for (int i = 0; i < w; ++i) drawPixel(x + i, y + j, c); }
    void drawCircle(int cx, int cy, int r, uint16_t c) {
        int x = r, y = 0, err = 1 - r;
        while (x >= y) {
            int px[8] = {x, y, -y, -x, -x, -y, y, x}, py[8] = {y, x, x, y, -y, -x, -x, -y};
            for (int k = 0; k < 8; ++k) drawPixel(cx + px[k], cy + py[k], c);
            ++y;
            if (err < 0) err += 2 * y + 1; else { --x; err += 2 * (y - x) + 1; }
        }
    }
    void fillCircle(int cx, int cy, int r, uint16_t c) {
        for (int j = -r; j <= r; ++j) for (int i = -r; i <= r; ++i) if (i * i + j * j <= r * r) drawPixel(cx + i, cy + j, c);
    }
    void fillTriangle(int x0, int y0, int x1, int y1, int x2, int y2, uint16_t c) {
        int minx = fmin(x0, fmin(x1, x2)), maxx = fmax(x0, fmax(x1, x2));
        int miny = fmin(y0, fmin(y1, y2)), maxy = fmax(y0, fmax(y1, y2));
        if (maxy < 0 || miny >= H) return;
        if (miny < 0) miny = 0;
        if (maxy >= H) maxy = H - 1;
        auto edge = [](int ax, int ay, int bx, int by, int px, int py) { return (bx - ax) * (py - ay) - (by - ay) * (px - ax); };
        for (int y = miny; y <= maxy; ++y) for (int x = minx; x <= maxx; ++x) {
            int a = edge(x0, y0, x1, y1, x, y), b = edge(x1, y1, x2, y2, x, y), d = edge(x2, y2, x0, y0, x, y);
            if ((a >= 0 && b >= 0 && d >= 0) || (a <= 0 && b <= 0 && d <= 0)) drawPixel(x, y, c);
        }
    }
    void setCursor(int x, int y) { cx = x; cy = y; }
    void setTextColor(uint16_t c) { tc = c; }
    void setTextSize(int s) { ts = s; }
    void setTextWrap(bool) {}
    // No font here: draw one outlined box per character so placement can be checked.
    void print(const char *s) {
        for (int i = 0; s[i]; ++i) {
            int x = cx + i * 6 * ts;
            for (int k = 0; k < 5 * ts; ++k) { drawPixel(x + k, cy, tc); drawPixel(x + k, cy + 7 * ts - 1, tc); }
            for (int k = 0; k < 7 * ts; ++k) { drawPixel(x, cy + k, tc); drawPixel(x + 5 * ts - 1, cy + k, tc); }
        }
    }
private:
    int W, H, cx = 0, cy = 0, ts = 1; uint16_t tc = 0xFFFF; uint16_t *buf;
};
