#pragma once
#include <stdint.h>
#include <stddef.h>
#include "driver/i2s.h"
typedef enum { LEDC_CHANNEL_0 } ledc_channel_t;
typedef enum { LEDC_TIMER_0 } ledc_timer_t;
typedef enum { PIXFORMAT_JPEG } pixformat_t;
typedef enum { FRAMESIZE_VGA } framesize_t;
typedef enum { CAMERA_FB_IN_PSRAM } camera_fb_location_t;
typedef enum { CAMERA_GRAB_LATEST } camera_grab_mode_t;
typedef struct {
    ledc_channel_t ledc_channel; ledc_timer_t ledc_timer;
    int pin_d0, pin_d1, pin_d2, pin_d3, pin_d4, pin_d5, pin_d6, pin_d7;
    int pin_xclk, pin_pclk, pin_vsync, pin_href, pin_sccb_sda, pin_sccb_scl, pin_pwdn, pin_reset;
    int xclk_freq_hz; pixformat_t pixel_format; framesize_t frame_size; int jpeg_quality;
    size_t fb_count; camera_fb_location_t fb_location; camera_grab_mode_t grab_mode;
} camera_config_t;
typedef struct { uint8_t *buf; size_t len; } camera_fb_t;
esp_err_t esp_camera_init(const camera_config_t *);
camera_fb_t *esp_camera_fb_get();
void esp_camera_fb_return(camera_fb_t *);
esp_err_t esp_camera_deinit();
