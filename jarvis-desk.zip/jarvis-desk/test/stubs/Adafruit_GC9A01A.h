#pragma once
#include <stdint.h>
extern uint16_t hostFrame[240 * 240];
class Adafruit_GC9A01A {
public:
    Adafruit_GC9A01A(int, int, int) {}
    void begin(uint32_t) {}
    void drawRGBBitmap(int x, int y, uint16_t *b, int w, int h) {
        for (int j = 0; j < h; ++j) for (int i = 0; i < w; ++i) hostFrame[(y + j) * 240 + x + i] = b[j * w + i];
    }
};
