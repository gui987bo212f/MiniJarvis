"""Tiny pyserial look-alike: the "port" is a subprocess (the firmware built for the PC)."""
import os, subprocess, threading, time

class SerialException(Exception):
    pass

class Serial:
    def __init__(self, port=None, baudrate=9600, timeout=None, write_timeout=None):
        self.port = port
        self.timeout = timeout
        self.write_timeout = write_timeout
        self.dtr = None
        self.rts = None
        self.is_open = False
        self._buf = bytearray()
        self._cv = threading.Condition()
        self.proc = None
        self.written = bytearray()

    def open(self):
        env = dict(os.environ)
        self.proc = subprocess.Popen([self.port], stdin=subprocess.PIPE, stdout=subprocess.PIPE, env=env, bufsize=0)
        self.is_open = True
        threading.Thread(target=self._pump, daemon=True).start()

    def _pump(self):
        while True:
            data = os.read(self.proc.stdout.fileno(), 4096)
            if not data:
                return
            with self._cv:
                self._buf.extend(data)
                self._cv.notify_all()

    def close(self):
        if self.proc:
            self.proc.stdin.close()
            try:
                self.proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self.proc.kill()
        self.is_open = False

    def __enter__(self):
        if not self.is_open:
            self.open()
        return self

    def __exit__(self, *a):
        self.close()

    def write(self, data):
        self.written.extend(data)
        self.proc.stdin.write(bytes(data))
        return len(data)

    def reset_input_buffer(self):
        with self._cv:
            self._buf.clear()

    def read(self, size=1):
        deadline = time.monotonic() + (self.timeout or 0)
        with self._cv:
            while len(self._buf) < size:
                left = deadline - time.monotonic()
                if left <= 0:
                    break
                self._cv.wait(left)
            out = bytes(self._buf[:size])
            del self._buf[:size]
            return out

    def read_until(self, expected=b"\n", size=None):
        deadline = time.monotonic() + (self.timeout or 0)
        out = bytearray()
        with self._cv:
            while True:
                while self._buf:
                    out.append(self._buf.pop(0))
                    if out.endswith(expected) or (size is not None and len(out) >= size):
                        return bytes(out)
                left = deadline - time.monotonic()
                if left <= 0:
                    return bytes(out)
                self._cv.wait(left)
