#!/usr/bin/env bash
# Builds the real firmware source for the PC (with Arduino/ESP-IDF stubs) and runs it
# against the real PC code. Needs g++, python3 and Pillow. No hardware required.
set -euo pipefail
cd "$(dirname "$0")"
g++ -std=gnu++11 -Wall -Wextra -Werror -O1 -Istubs -I../firmware/include \
    ../firmware/src/main.cpp harness.cpp -o fw
PYTHONPATH=fakeserial:../pc python3 test_integration.py
