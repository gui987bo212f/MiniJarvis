// Jarvis desk assistant - XIAO ESP32-S3 Sense.
// The device only answers the PC over USB serial; it never asks the host to do anything.
//
// Commands (one per line): STATUS SLEEP WAKE TALK QUIET OPENED RECORD SNAP
//                          TIME <seconds since local midnight>   PLAY <bytes>
// Replies: "JARVIS state=..." / "JARVIS AUDIO n" + PCM / "JARVIS IMAGE n" + JPEG /
//          "JARVIS READY" + "JARVIS ACK" for PLAY / "JARVIS ERR code".
#include <Arduino.h>
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_GC9A01A.h>
#include <driver/i2s.h>
#include <esp_camera.h>
#include <esp_heap_caps.h>
#include <esp_log.h>
#include <esp_timer.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "config.h"

namespace {
constexpr uint32_t TALK_HOLD_MS = 1800;
constexpr uint32_t OPENED_FLASH_MS = 460;
constexpr uint32_t IDLE_FRAME_MS = 240;
constexpr uint32_t TALK_FRAME_MS = 125;
constexpr uint32_t REST_FRAME_MS = 100;
constexpr uint32_t REST_AFTER_MS = 30000;  // inactivity before the clock appears
constexpr int64_t DAY_MS = 86400000LL;

constexpr int PANEL_SIZE = 240;
constexpr int CENTER = 120;
constexpr int BAND_HEIGHT = 16;

constexpr uint16_t rgb(uint8_t r, uint8_t g, uint8_t b) {
    return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);
}

constexpr uint16_t BACKGROUND = rgb(0, 7, 9);
constexpr uint16_t WORDMARK = rgb(78, 239, 255);
constexpr uint16_t WORDMARK_HALO = rgb(0, 66, 81);
constexpr uint16_t RECORD_ACCENT = rgb(255, 124, 86);
constexpr uint16_t FLASH_ACCENT = rgb(191, 255, 247);

// Microphone (PDM on I2S0) and speaker (I2S1).
constexpr i2s_port_t MIC_PORT = I2S_NUM_0;
constexpr i2s_port_t SPK_PORT = I2S_NUM_1;
constexpr uint32_t SAMPLE_RATE = 16000;
constexpr size_t CAPTURE_SAMPLES = 2 * SAMPLE_RATE;   // 2 s
constexpr size_t AUDIO_BYTES = 2 * CAPTURE_SAMPLES;   // mono, 16-bit
constexpr size_t MIC_BLOCK_FRAMES = 256;
constexpr size_t MIC_STARTUP_FRAMES = 18 * MIC_BLOCK_FRAMES;  // ~288 ms of settling
constexpr int MIC_GAIN = 4;  // the Sense PDM mic is quiet; tune if it clips or is faint
constexpr uint32_t MIC_READ_TIMEOUT_MS = 120;
constexpr uint32_t MIC_CAPTURE_TIMEOUT_MS = 3500;

constexpr size_t PLAY_CHUNK = 2048;                   // bytes per ACK
constexpr size_t MAX_PLAY_BYTES = 1200000;            // ~37 s at 16 kHz mono
constexpr uint32_t PLAY_TIMEOUT_MS = 3000;
constexpr size_t SPK_BLOCK_SAMPLES = 256;

constexpr size_t MAX_JPEG_BYTES = 200000;
constexpr uint32_t OUTPUT_STALL_MS = 5000;

constexpr size_t COMMAND_MAX = 24;

Adafruit_GC9A01A tft(TFT_CS, TFT_DC, TFT_RST);
// Composite each band before sending it. Only 7,680 bytes of pixel storage.
GFXcanvas16 band(PANEL_SIZE, BAND_HEIGHT);
int16_t sineTable[360];

enum class HudMode : uint8_t { Idle, Rest, Talking, Recording };

struct HudFrame {
    HudMode mode;
    bool flash;
    int outerAngle;
    int innerAngle;
    uint8_t pulse;
    int hourAngle;    // degrees clockwise from 12
    int minuteAngle;
    int secondAngle;
};

bool asleep = false;       // manual SLEEP: show the clock until WAKE
bool talking = false;
uint32_t talkStart = 0;
uint32_t lastTalk = 0;
bool openedFlash = false;
uint32_t openedAt = 0;
uint32_t lastActivity = 0;  // last command that counts as interaction

int64_t clockOffsetMs = 0;  // local time of day = uptime + offset (set by TIME)

bool frameDrawn = false;
HudMode lastMode = HudMode::Idle;
bool lastFlash = false;
uint32_t lastFrameAt = 0;

char command[COMMAND_MAX + 2];  // longest line + one trailing CR
size_t commandLength = 0;
bool discardLine = false;
char reply[64];
size_t replyLength = 0;

uint8_t *outBuf = nullptr;  // payload queued for the host (audio or JPEG)
size_t outLen = 0;
size_t outSent = 0;
uint32_t outProgressAt = 0;

uint8_t playBytes[PLAY_CHUNK];

uint16_t blend(uint16_t a, uint16_t b, uint8_t weight) {
    const unsigned keep = 255 - weight;
    const unsigned r = ((a >> 11) * keep + (b >> 11) * weight + 127) / 255;
    const unsigned g = (((a >> 5) & 63) * keep + ((b >> 5) & 63) * weight + 127) / 255;
    const unsigned blue = ((a & 31) * keep + (b & 31) * weight + 127) / 255;
    return (r << 11) | (g << 5) | blue;
}

struct Point {
    int x;
    int y;
};

Point polar(int radius, int angle) {
    angle %= 360;
    if (angle < 0) angle += 360;
    return {
        CENTER + radius * sineTable[(angle + 90) % 360] / 1024,
        CENTER + radius * sineTable[angle] / 1024
    };
}

// Angle in degrees clockwise from 12 o'clock (polar() has 0 = 3 o'clock).
Point clockPolar(int radius, int degrees) { return polar(radius, degrees - 90); }

int64_t msOfDay() {
    int64_t t = (esp_timer_get_time() / 1000 + clockOffsetMs) % DAY_MS;
    if (t < 0) t += DAY_MS;
    return t;
}

bool isResting(uint32_t now) {
    return asleep || now - lastActivity >= REST_AFTER_MS;
}

void bandLine(Point a, Point b, int top, uint16_t color) {
    if ((a.y < top && b.y < top) ||
        (a.y >= top + BAND_HEIGHT && b.y >= top + BAND_HEIGHT)) return;
    band.drawLine(a.x, a.y - top, b.x, b.y - top, color);
}

void thickLine(Point a, Point b, int top, uint16_t color) {
    bandLine(a, b, top, color);
    bandLine({a.x + 1, a.y}, {b.x + 1, b.y}, top, color);
    bandLine({a.x, a.y + 1}, {b.x, b.y + 1}, top, color);
}

void arc(int radius, int start, int length, int top, uint16_t color) {
    Point previous = polar(radius, start);
    for (int swept = 2; swept < length; swept += 2) {
        const Point next = polar(radius, start + swept);
        bandLine(previous, next, top, color);
        previous = next;
    }
    bandLine(previous, polar(radius, start + length), top, color);
}

void sweptArc(int radius, int start, int length, int top,
              uint16_t halo, uint16_t core, uint16_t tip) {
    arc(radius - 1, start - 2, length + 4, top, halo);
    arc(radius + 1, start - 2, length + 4, top, halo);
    arc(radius, start, length, top, core);
    arc(radius, start + length - 8, 8, top, tip);
}

void drawWordmark(int top, int glow, uint16_t color) {
    // Narrow 5x7 capitals, with two-column stems and separately drawn periods.
    static constexpr uint8_t glyphs[][7] = {
        {0x0F, 0x03, 0x03, 0x03, 0x03, 0x1B, 0x0E},  // J
        {0x0E, 0x1B, 0x1B, 0x1F, 0x1B, 0x1B, 0x1B},  // A
        {0x1E, 0x1B, 0x1B, 0x1E, 0x1C, 0x1E, 0x1B},  // R
        {0x1B, 0x1B, 0x1B, 0x1B, 0x0E, 0x0E, 0x04},  // V
        {0x0E, 0x0C, 0x0C, 0x0C, 0x0C, 0x0C, 0x0E},  // I
        {0x0F, 0x18, 0x18, 0x0E, 0x03, 0x03, 0x1E}   // S
    };
    constexpr int LETTER_STEP = 19;
    constexpr int WORD_X = (PANEL_SIZE - (5 * LETTER_STEP + 10)) / 2;
    constexpr int WORD_Y = CENTER - 10;
    if (top >= WORD_Y + 21 + glow || top + BAND_HEIGHT <= WORD_Y - glow) return;

    for (int letter = 0; letter < 6; ++letter) {
        const int x = WORD_X + letter * LETTER_STEP;
        for (int row = 0; row < 7; ++row) {
            for (int col = 0; col < 5; ++col) {
                if (glyphs[letter][row] & (0x10 >> col)) {
                    band.fillRect(x + 2 * col - glow, WORD_Y + 3 * row - top - glow,
                                  2 + 2 * glow, 3 + 2 * glow, color);
                }
            }
        }
        if (letter != 5) {
            band.fillRect(x + 12 - glow, WORD_Y + 17 - top - glow,
                          4 + 2 * glow, 4 + 2 * glow, color);
        }
    }
}

void drawHudBand(int top, const HudFrame &frame) {
    const bool speech = frame.mode == HudMode::Talking;
    const bool record = frame.mode == HudMode::Recording;

    band.fillScreen(BACKGROUND);

    static constexpr uint8_t radii[] = {58, 70, 84, 95, 106, 116};
    for (unsigned i = 0; i < sizeof(radii) / sizeof(radii[0]); ++i) {
        uint16_t color = i % 2 ? rgb(0, 65, 76) : rgb(0, 40, 49);
        if (frame.flash) color = blend(color, FLASH_ACCENT, i % 2 ? 144 : 86);
        band.drawCircle(CENTER, CENTER - top, radii[i], color);
    }

    const uint16_t tickLow = rgb(4, 70, 82);
    const uint16_t tickHigh = record ? RECORD_ACCENT
                            : frame.flash ? FLASH_ACCENT : rgb(24, 152, 169);
    for (int angle = 0; angle < 360; angle += 6) {
        const int segment = angle % 60;
        if (segment < 42) {
            const bool major = segment == 0 || segment == 30;
            bandLine(polar(major ? 109 : 111, angle), polar(114, angle),
                     top, major ? tickHigh : tickLow);
        }
        if (segment >= 30 && segment <= 48) {
            bandLine(polar(75, angle), polar(segment == 42 ? 81 : 78, angle),
                     top, segment == 42 ? tickHigh : tickLow);
        }
    }

    uint16_t core = rgb(20, 177, 195);
    uint16_t secondary = rgb(0, 118, 137);
    uint16_t halo = rgb(0, 58, 70);
    uint16_t tip = rgb(89, 227, 236);
    if (speech) {
        core = blend(rgb(26, 229, 248), FLASH_ACCENT, frame.pulse);
        secondary = blend(rgb(0, 164, 189), WORDMARK, frame.pulse);
        halo = blend(rgb(0, 84, 101), rgb(0, 170, 194), frame.pulse);
        tip = FLASH_ACCENT;
    } else if (record) {
        core = RECORD_ACCENT;
        secondary = rgb(183, 61, 42);
        halo = rgb(82, 26, 19);
        tip = rgb(255, 207, 160);
    }
    if (frame.flash) {
        core = FLASH_ACCENT;
        secondary = blend(secondary, FLASH_ACCENT, 162);
        halo = blend(halo, FLASH_ACCENT, 84);
        tip = rgb(255, 255, 255);
    }

    sweptArc(106, 205 + frame.outerAngle, speech ? 64 : 49, top, halo, core, tip);
    sweptArc(106, 22 + frame.outerAngle, 31, top, halo, secondary, core);
    sweptArc(95, 310 - frame.innerAngle, speech ? 55 : 39, top, halo, core, tip);
    sweptArc(95, 104 - frame.innerAngle, 51, top, halo, secondary, core);
    sweptArc(84, 146 + frame.outerAngle, 41, top, halo, secondary, core);
    sweptArc(84, 351 + frame.outerAngle, 22, top, halo, secondary, core);

    if (frame.mode == HudMode::Idle && !frame.flash) {
        const int sweep = frame.outerAngle * 3;
        arc(116, sweep, 18, top, rgb(0, 99, 112));
        arc(117, sweep + 5, 10, top, rgb(0, 34, 42));
    }

    drawWordmark(top, 1, WORDMARK_HALO);
    drawWordmark(top, 0, WORDMARK);

    if (record && top < 152 && top + BAND_HEIGHT > 144) {
        band.fillCircle(86, 147 - top, 2, RECORD_ACCENT);
        band.setCursor(94, 144 - top);
        band.setTextColor(RECORD_ACCENT);
        band.print("RECORDING");
    }
}

// Diamond-shaped hand: tip at `length`, tail at `tail`, `half` wide at the pivot.
void handShape(int length, int tail, int half, int degrees, int top, uint16_t color) {
    const Point tip = clockPolar(length, degrees);
    const Point back = clockPolar(tail, degrees + 180);
    const Point left = clockPolar(half, degrees - 90);
    const Point right = clockPolar(half, degrees + 90);
    int lowY = tip.y;
    int highY = tip.y;
    const Point others[] = {back, left, right};
    for (const Point &p : others) {
        if (p.y < lowY) lowY = p.y;
        if (p.y > highY) highY = p.y;
    }
    if (highY < top || lowY >= top + BAND_HEIGHT) return;
    band.fillTriangle(left.x, left.y - top, tip.x, tip.y - top,
                      right.x, right.y - top, color);
    band.fillTriangle(left.x, left.y - top, back.x, back.y - top,
                      right.x, right.y - top, color);
}

void numeral(const char *text, int x, int y, int top, uint16_t color) {
    if (top >= y + 16 || top + BAND_HEIGHT <= y) return;
    band.setTextSize(2);
    band.setTextColor(color);
    band.setCursor(x, y - top);
    band.print(text);
    band.setTextSize(1);
}

void drawClockBand(int top, const HudFrame &frame) {
    band.fillScreen(BACKGROUND);

    band.drawCircle(CENTER, CENTER - top, 117, rgb(0, 40, 49));
    band.drawCircle(CENTER, CENTER - top, 113, rgb(0, 65, 76));

    const uint16_t minorTick = rgb(4, 70, 82);
    const uint16_t majorTick = rgb(24, 152, 169);
    for (int i = 0; i < 60; ++i) {
        const int deg = i * 6;
        if (i % 5 == 0) {
            thickLine(clockPolar(97, deg), clockPolar(110, deg), top, majorTick);
        } else {
            bandLine(clockPolar(105, deg), clockPolar(110, deg), top, minorTick);
        }
    }

    const uint16_t figure = rgb(24, 152, 169);
    numeral("12", CENTER - 12, CENTER - 84 - 8, top, figure);
    numeral("3", CENTER + 84 - 6, CENTER - 8, top, figure);
    numeral("6", CENTER - 6, CENTER + 84 - 8, top, figure);
    numeral("9", CENTER - 84 - 6, CENTER - 8, top, figure);

    // Slow orbiting arcs keep the face alive between ticks.
    arc(116, frame.outerAngle, 40, top, rgb(0, 99, 112));
    arc(116, frame.outerAngle + 180, 20, top, rgb(0, 65, 76));

    handShape(62, 12, 5, frame.hourAngle, top, rgb(0, 118, 137));
    handShape(60, 11, 2, frame.hourAngle, top, WORDMARK);
    handShape(92, 14, 4, frame.minuteAngle, top, rgb(0, 118, 137));
    handShape(90, 13, 1, frame.minuteAngle, top, WORDMARK);

    const Point secondTip = clockPolar(102, frame.secondAngle);
    const Point secondBack = clockPolar(22, frame.secondAngle + 180);
    bandLine(secondBack, secondTip, top, RECORD_ACCENT);
    bandLine({secondBack.x + 1, secondBack.y}, {secondTip.x + 1, secondTip.y},
             top, RECORD_ACCENT);

    if (top < CENTER + 7 && top + BAND_HEIGHT > CENTER - 7) {
        band.fillCircle(CENTER, CENTER - top, 6, WORDMARK);
        band.fillCircle(CENTER, CENTER - top, 2, RECORD_ACCENT);
    }
}

void expireOverlays(uint32_t now) {
    if (talking && now - lastTalk >= TALK_HOLD_MS) talking = false;
    if (openedFlash && now - openedAt >= OPENED_FLASH_MS) openedFlash = false;
}

void render(uint32_t now, bool recording = false) {
    expireOverlays(now);
    const HudMode mode = recording ? HudMode::Recording
                       : talking ? HudMode::Talking
                       : isResting(now) ? HudMode::Rest : HudMode::Idle;
    const bool flash = openedFlash && !recording && mode == HudMode::Idle;
    const uint32_t interval = mode == HudMode::Talking ? TALK_FRAME_MS
                            : mode == HudMode::Rest ? REST_FRAME_MS
                            : mode == HudMode::Idle && !flash ? IDLE_FRAME_MS : 0;
    if (frameDrawn && mode == lastMode && flash == lastFlash &&
        (interval == 0 || now - lastFrameAt < interval)) return;
    if (!band.getBuffer()) return;

    HudFrame frame = {mode, flash, 0, 0, 0, 0, 0, 0};
    if (mode == HudMode::Talking) {
        const uint32_t elapsed = now - talkStart;
        frame.outerAngle = (elapsed / 12) % 360;
        frame.innerAngle = (elapsed / 17) % 360;
        const uint32_t phase = elapsed % 800;
        frame.pulse = (400 - (phase < 400 ? phase : 800 - phase)) * 255 / 400;
    } else if (mode == HudMode::Idle) {
        frame.outerAngle = (now / IDLE_FRAME_MS) % 120;
        frame.innerAngle = frame.outerAngle / 2;
    } else if (mode == HudMode::Rest) {
        const int64_t t = msOfDay();
        frame.secondAngle = static_cast<int>((t % 60000) * 360 / 60000);
        frame.minuteAngle = static_cast<int>((t % 3600000) * 360 / 3600000);
        frame.hourAngle = static_cast<int>((t % 43200000) * 360 / 43200000);
        frame.outerAngle = (now / 50) % 360;
    }

    // No separate clear pass: each transfer contains the finished pixels.
    for (int top = 0; top < PANEL_SIZE; top += BAND_HEIGHT) {
        if (mode == HudMode::Rest) drawClockBand(top, frame);
        else drawHudBand(top, frame);
        tft.drawRGBBitmap(0, top, band.getBuffer(), PANEL_SIZE, BAND_HEIGHT);
    }
    frameDrawn = true;
    lastMode = mode;
    lastFlash = flash;
    lastFrameAt = now;
}

void *allocBuffer(size_t bytes) {
    void *p = heap_caps_malloc(bytes, MALLOC_CAP_SPIRAM);
    return p ? p : malloc(bytes);
}

// ---------------------------------------------------------------- microphone

const char *captureAudio(int16_t *stereo) {
    i2s_config_t cfg = {};
    cfg.mode = static_cast<i2s_mode_t>(I2S_MODE_MASTER | I2S_MODE_RX | I2S_MODE_PDM);
    cfg.sample_rate = SAMPLE_RATE;
    cfg.bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT;
    // Read both slots; stereoToMono() keeps whichever one carries the microphone.
    cfg.channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT;
    cfg.communication_format = I2S_COMM_FORMAT_STAND_I2S;
    cfg.intr_alloc_flags = ESP_INTR_FLAG_LEVEL1;
    cfg.dma_buf_count = 8;
    cfg.dma_buf_len = MIC_BLOCK_FRAMES;
    cfg.use_apll = false;

    if (i2s_driver_install(MIC_PORT, &cfg, 0, nullptr) != ESP_OK) return "mic_init";

    i2s_pin_config_t pins = {};
    pins.mck_io_num = I2S_PIN_NO_CHANGE;
    pins.bck_io_num = I2S_PIN_NO_CHANGE;
    pins.ws_io_num = MIC_PDM_CLK;  // PDM clock
    pins.data_out_num = I2S_PIN_NO_CHANGE;
    pins.data_in_num = MIC_PDM_DATA;

    const char *error = nullptr;
    if (i2s_set_pin(MIC_PORT, &pins) != ESP_OK) {
        error = "mic_pins";
    } else {
        int16_t block[2 * MIC_BLOCK_FRAMES];
        const uint32_t started = millis();
        const TickType_t readTimeout = pdMS_TO_TICKS(MIC_READ_TIMEOUT_MS);
        const size_t totalFrames = MIC_STARTUP_FRAMES + CAPTURE_SAMPLES;

        for (size_t offset = 0; offset < totalFrames;) {
            if (millis() - started >= MIC_CAPTURE_TIMEOUT_MS) {
                error = "mic_timeout";
                break;
            }
            const size_t remaining = totalFrames - offset;
            const size_t count = remaining < MIC_BLOCK_FRAMES ? remaining : MIC_BLOCK_FRAMES;
            const size_t requested = count * 2 * sizeof(int16_t);
            size_t received = 0;
            const esp_err_t result = i2s_read(MIC_PORT, block, requested, &received, readTimeout);
            if (result != ESP_OK || received != requested) {
                error = result == ESP_ERR_TIMEOUT || result == ESP_OK ? "mic_timeout" : "mic_read";
                break;
            }
            if (offset >= MIC_STARTUP_FRAMES) {
                memcpy(stereo + 2 * (offset - MIC_STARTUP_FRAMES), block, requested);
            }
            offset += count;
        }
    }

    const esp_err_t stopped = i2s_stop(MIC_PORT);
    const esp_err_t removed = i2s_driver_uninstall(MIC_PORT);
    // Release the clock and data lines even on a failed capture.
    pinMode(MIC_PDM_CLK, INPUT);
    pinMode(MIC_PDM_DATA, INPUT);
    if (!error && (stopped != ESP_OK || removed != ESP_OK)) error = "mic_stop";
    return error;
}

// In place: pick the slot with the signal, remove DC offset, apply gain.
// Output is `frames` mono samples at the start of the buffer.
void stereoToMono(int16_t *buf, size_t frames) {
    int64_t sum[2] = {0, 0};
    for (size_t i = 0; i < frames; ++i) {
        sum[0] += buf[2 * i];
        sum[1] += buf[2 * i + 1];
    }
    const int mean[2] = {static_cast<int>(sum[0] / static_cast<int64_t>(frames)),
                         static_cast<int>(sum[1] / static_cast<int64_t>(frames))};
    int64_t energy[2] = {0, 0};
    for (size_t i = 0; i < frames; ++i) {
        for (int c = 0; c < 2; ++c) {
            const int d = buf[2 * i + c] - mean[c];
            energy[c] += d < 0 ? -d : d;
        }
    }
    const int slot = energy[1] > energy[0] ? 1 : 0;
    for (size_t i = 0; i < frames; ++i) {
        int v = (buf[2 * i + slot] - mean[slot]) * MIC_GAIN;
        if (v > 32767) v = 32767;
        if (v < -32768) v = -32768;
        buf[i] = static_cast<int16_t>(v);
    }
}

// ------------------------------------------------------------- host payloads

void beginOutput(uint8_t *buffer, size_t length) {
    outBuf = buffer;
    outLen = length;
    outSent = 0;
    outProgressAt = millis();
}

void serviceOutput() {
    const uint32_t now = millis();
    const int room = Serial.availableForWrite();
    if (room > 0) {
        const size_t remaining = outLen - outSent;
        const size_t capacity = static_cast<size_t>(room);
        const size_t count = remaining < capacity ? remaining : capacity;
        const size_t written = Serial.write(outBuf + outSent, count);
        if (written > 0) {
            outSent += written;
            outProgressAt = now;
        }
    }
    // Free the buffer when done, or give up if the host stopped reading.
    if (outSent == outLen || now - outProgressAt > OUTPUT_STALL_MS) {
        free(outBuf);
        outBuf = nullptr;
    }
}

void startRecording() {
    int16_t *buffer = static_cast<int16_t *>(allocBuffer(2 * AUDIO_BYTES));
    if (!buffer) {
        Serial.print("JARVIS ERR no_memory\n");
        return;
    }

    render(millis(), true);
    const char *error = captureAudio(buffer);
    if (error) {
        free(buffer);
        Serial.printf("JARVIS ERR %s\n", error);
        return;
    }
    stereoToMono(buffer, CAPTURE_SAMPLES);

    // Do not announce a frame until the complete payload is in memory.
    Serial.printf("JARVIS AUDIO %u\n", static_cast<unsigned>(AUDIO_BYTES));
    beginOutput(reinterpret_cast<uint8_t *>(buffer), AUDIO_BYTES);
}

// -------------------------------------------------------------------- camera

void startSnapshot() {
    camera_config_t c = {};
    c.ledc_channel = LEDC_CHANNEL_0;
    c.ledc_timer = LEDC_TIMER_0;
    c.pin_d0 = 15;  c.pin_d1 = 17; c.pin_d2 = 18; c.pin_d3 = 16;
    c.pin_d4 = 14;  c.pin_d5 = 12; c.pin_d6 = 11; c.pin_d7 = 48;
    c.pin_xclk = 10; c.pin_pclk = 13; c.pin_vsync = 38; c.pin_href = 47;
    c.pin_sccb_sda = 40; c.pin_sccb_scl = 39;
    c.pin_pwdn = -1; c.pin_reset = -1;
    c.xclk_freq_hz = 20000000;
    c.pixel_format = PIXFORMAT_JPEG;
    c.frame_size = FRAMESIZE_VGA;
    c.jpeg_quality = 10;  // lower number = better quality
    c.fb_count = 2;
    c.fb_location = CAMERA_FB_IN_PSRAM;
    c.grab_mode = CAMERA_GRAB_LATEST;

    // The camera is powered up only for the shot, which keeps the board cool.
    if (esp_camera_init(&c) != ESP_OK) {
        Serial.print("JARVIS ERR cam_init\n");
        return;
    }
    for (int i = 0; i < 6; ++i) {  // let exposure and white balance settle
        camera_fb_t *warm = esp_camera_fb_get();
        if (warm) esp_camera_fb_return(warm);
    }
    camera_fb_t *fb = esp_camera_fb_get();
    if (!fb) {
        esp_camera_deinit();
        Serial.print("JARVIS ERR cam_capture\n");
        return;
    }
    if (fb->len == 0 || fb->len > MAX_JPEG_BYTES) {
        esp_camera_fb_return(fb);
        esp_camera_deinit();
        Serial.print("JARVIS ERR cam_size\n");
        return;
    }
    uint8_t *copy = static_cast<uint8_t *>(allocBuffer(fb->len));
    if (!copy) {
        esp_camera_fb_return(fb);
        esp_camera_deinit();
        Serial.print("JARVIS ERR no_memory\n");
        return;
    }
    const size_t length = fb->len;
    memcpy(copy, fb->buf, length);
    esp_camera_fb_return(fb);
    esp_camera_deinit();

    Serial.printf("JARVIS IMAGE %u\n", static_cast<unsigned>(length));
    beginOutput(copy, length);
}

// ------------------------------------------------------------------- speaker

void drainInput() {
    uint32_t quietSince = millis();
    const uint32_t started = quietSince;
    while (millis() - started < 2000 && millis() - quietSince < 150) {
        if (Serial.available() > 0) {
            Serial.read();
            quietSince = millis();
        } else {
            delay(1);
        }
    }
}

void keepTalking() {
    const uint32_t now = millis();
    if (!talking) talkStart = now;
    talking = true;
    lastTalk = now;
}

// Stream mono 16-bit PCM from the host to the amplifier, one ACK per chunk.
void playStream(size_t total) {
    i2s_config_t cfg = {};
    cfg.mode = static_cast<i2s_mode_t>(I2S_MODE_MASTER | I2S_MODE_TX);
    cfg.sample_rate = SAMPLE_RATE;
    cfg.bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT;
    cfg.channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT;  // same sample on both slots
    cfg.communication_format = I2S_COMM_FORMAT_STAND_I2S;
    cfg.intr_alloc_flags = ESP_INTR_FLAG_LEVEL1;
    cfg.dma_buf_count = 8;
    cfg.dma_buf_len = 1024;  // ~256 ms of buffer so a slow display frame never starves it
    cfg.use_apll = false;
    cfg.tx_desc_auto_clear = true;

    if (i2s_driver_install(SPK_PORT, &cfg, 0, nullptr) != ESP_OK) {
        Serial.print("JARVIS ERR spk_init\n");
        return;
    }
    i2s_pin_config_t pins = {};
    pins.mck_io_num = I2S_PIN_NO_CHANGE;
    pins.bck_io_num = SPK_BCLK;
    pins.ws_io_num = SPK_LRC;
    pins.data_out_num = SPK_DIN;
    pins.data_in_num = I2S_PIN_NO_CHANGE;
    if (i2s_set_pin(SPK_PORT, &pins) != ESP_OK) {
        i2s_driver_uninstall(SPK_PORT);
        Serial.print("JARVIS ERR spk_pins\n");
        return;
    }

    Serial.print("JARVIS READY\n");
    keepTalking();

    const char *error = nullptr;
    size_t received = 0;
    uint32_t lastData = millis();
    int16_t stereo[2 * SPK_BLOCK_SAMPLES];

    while (received < total && !error) {
        const size_t chunk = total - received < PLAY_CHUNK ? total - received : PLAY_CHUNK;
        size_t got = 0;
        while (got < chunk) {
            const int available = Serial.available();
            const uint32_t now = millis();
            if (available <= 0) {
                if (now - lastData > PLAY_TIMEOUT_MS) {
                    error = "play_timeout";
                    break;
                }
                keepTalking();
                render(now);
                delay(1);
                continue;
            }
            size_t count = static_cast<size_t>(available);
            if (count > chunk - got) count = chunk - got;
            count = Serial.readBytes(reinterpret_cast<char *>(playBytes) + got, count);
            got += count;
            if (count > 0) lastData = now;
        }
        if (error) break;

        const size_t samples = chunk / 2;
        for (size_t done = 0; done < samples && !error;) {
            const size_t n = samples - done < SPK_BLOCK_SAMPLES ? samples - done : SPK_BLOCK_SAMPLES;
            for (size_t i = 0; i < n; ++i) {
                const int16_t s = static_cast<int16_t>(
                    playBytes[2 * (done + i)] | (playBytes[2 * (done + i) + 1] << 8));
                stereo[2 * i] = s;
                stereo[2 * i + 1] = s;
            }
            const size_t bytes = n * 2 * sizeof(int16_t);
            size_t written = 0;
            const esp_err_t result = i2s_write(SPK_PORT, stereo, bytes, &written,
                                               pdMS_TO_TICKS(1000));
            if (result != ESP_OK || written != bytes) error = "spk_write";
            done += n;
        }
        if (error) break;

        received += chunk;
        keepTalking();
        Serial.print("JARVIS ACK\n");
    }

    if (error) {
        Serial.printf("JARVIS ERR %s\n", error);
        drainInput();
        discardLine = true;
    } else {
        // Let the buffered audio finish while the display keeps animating.
        for (uint32_t end = millis() + 300; millis() < end;) {
            keepTalking();
            render(millis());
            delay(5);
        }
    }

    i2s_zero_dma_buffer(SPK_PORT);
    i2s_stop(SPK_PORT);
    i2s_driver_uninstall(SPK_PORT);
    pinMode(SPK_BCLK, INPUT);
    pinMode(SPK_LRC, INPUT);
    pinMode(SPK_DIN, INPUT);

    lastTalk = millis() - TALK_HOLD_MS + 250;  // overlay fades out shortly after
}

// ------------------------------------------------------------------ commands

bool is(const char *word, size_t length) {
    return strlen(word) == length && memcmp(command, word, length) == 0;
}

bool hasPrefix(const char *prefix, size_t length) {
    const size_t n = strlen(prefix);
    return length > n && memcmp(command, prefix, n) == 0;
}

bool parseNumber(size_t offset, size_t length, uint32_t maxValue, uint32_t &out) {
    if (length <= offset || length - offset > 9) return false;
    uint32_t value = 0;
    for (size_t i = offset; i < length; ++i) {
        if (command[i] < '0' || command[i] > '9') return false;
        value = value * 10 + static_cast<uint32_t>(command[i] - '0');
    }
    if (value > maxValue) return false;
    out = value;
    return true;
}

void executeCommand(size_t length) {
    const uint32_t now = millis();
    expireOverlays(now);

    bool status = false;
    uint32_t number = 0;
    if (is("STATUS", length)) {
        status = true;  // read-only; does not count as interaction
    } else if (hasPrefix("TIME ", length)) {
        if (!parseNumber(5, length, 86399, number)) return;
        clockOffsetMs = static_cast<int64_t>(number) * 1000 - esp_timer_get_time() / 1000;
    } else if (is("TALK", length)) {
        lastActivity = now;
        if (!talking) talkStart = now;
        talking = true;
        lastTalk = now;
        return;
    } else if (is("QUIET", length)) {
        lastActivity = now;
        talking = false;
        return;
    } else if (is("SLEEP", length)) {
        lastActivity = now;
        asleep = true;
    } else if (is("WAKE", length)) {
        lastActivity = now;
        asleep = false;
    } else if (is("OPENED", length)) {
        lastActivity = now;
        openedFlash = true;
        openedAt = now;
    } else if (is("RECORD", length)) {
        lastActivity = now;
        startRecording();
        return;
    } else if (is("SNAP", length)) {
        lastActivity = now;
        startSnapshot();
        return;
    } else if (hasPrefix("PLAY ", length)) {
        lastActivity = now;
        if (!parseNumber(5, length, MAX_PLAY_BYTES, number) || number < 2 || (number & 1)) {
            Serial.print("JARVIS ERR bad_play\n");
            return;
        }
        playStream(number);
        return;
    } else {
        return;
    }

    // Only STATUS reports the speaking overlay and the clock. Other replies report manual state.
    const char *state = status && talking ? "TALKING"
                      : asleep ? "ASLEEP"
                      : status && isResting(now) ? "RESTING" : "HAPPY";
    const int written = snprintf(reply, sizeof(reply), "JARVIS state=%s\n", state);
    if (written > 0 && static_cast<size_t>(written) < sizeof(reply)) {
        replyLength = static_cast<size_t>(written);
    }
}

void flushReply() {
    if (replyLength != 0 && Serial.availableForWrite() >= static_cast<int>(replyLength)) {
        Serial.write(reinterpret_cast<const uint8_t *>(reply), replyLength);
        replyLength = 0;
    }
}

void serviceSerial() {
    if (outBuf) {
        // Defer command replies until the last byte of this frame is queued.
        serviceOutput();
        return;
    }

    flushReply();
    for (uint8_t i = 0; i < 64 && replyLength == 0 && Serial.available() > 0; ++i) {
        const int ch = Serial.read();
        if (ch < 0) break;
        if (ch == '\n') {
            if (!discardLine) {
                size_t length = commandLength;
                if (length > 0 && command[length - 1] == '\r') --length;
                executeCommand(length);
            }
            commandLength = 0;
            discardLine = false;
            if (outBuf) return;
            flushReply();
        } else if (!discardLine) {
            if (commandLength == COMMAND_MAX + 1 || (ch != '\r' && (ch < 32 || ch > 126))) {
                discardLine = true;
            } else {
                command[commandLength++] = static_cast<char>(ch);
            }
        }
    }
}
}  // namespace

void setup() {
    // Keep driver diagnostics off the protocol port.
    esp_log_level_set("*", ESP_LOG_NONE);

    // The panel is write-only. The display driver owns CS.
    SPI.begin(TFT_SCK, -1, TFT_MOSI, -1);
    tft.begin(27000000);

    for (int degree = 0; degree < 360; ++degree) {
        sineTable[degree] = static_cast<int16_t>(lroundf(
            1024.0f * sinf(degree * 0.01745329252f)));
    }
    band.setTextWrap(false);
    band.setTextSize(1);
    render(millis());

    Serial.setRxBufferSize(8192);  // must be set before begin()
    Serial.setTxBufferSize(4096);
    Serial.begin(115200);
}

void loop() {
    serviceSerial();
    if (!outBuf) render(millis());
    delay(1);
}
