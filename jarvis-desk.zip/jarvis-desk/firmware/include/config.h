#pragma once

// Seeed XIAO ESP32-S3 Sense. "Dn" is the label printed on the board.
// The camera and the PDM microphone are on the Sense expansion board and
// use internal pins (not on the headers), so they do not appear here.

// Round display GC9A01A (SPI). Wire the module's BLK pin to 3V3.
#define TFT_CS   1   // D0
#define TFT_DC   2   // D1
#define TFT_RST  4   // D3
#define TFT_SCK  7   // D8
#define TFT_MOSI 9   // D10

// Speaker amplifier MAX98357A (I2S)
#define SPK_DIN  3   // D2
#define SPK_BCLK 5   // D4
#define SPK_LRC  6   // D5

// PDM microphone of the Sense board
#define MIC_PDM_CLK  42
#define MIC_PDM_DATA 41
