# Jarvis de mesa: placa, ligações e PCB

## Placa escolhida
**Seeed XIAO ESP32-S3 Sense** (21 x 17,8 mm). Já traz na mesma placa: câmera, microfone PDM, 8 MB de PSRAM e USB-C. Substitui o esp32dev e a ESP32-CAM, então o Jarvis fica com **uma placa, um cabo USB**.

## Lista de peças
| Peça | Observação |
|---|---|
| XIAO ESP32-S3 **Sense** | tem que ser a versão Sense (com câmera e microfone) |
| Display GC9A01A 1,28" redondo, 240x240 (SPI) | módulo de 8 pinos: VCC, GND, SCL, SDA, DC, CS, RST, BLK (a ordem muda por fabricante) |
| Amplificador MAX98357A (I2S) | módulo breakout; use o rótulo impresso de cada pino |
| Alto-falante 4 Ω, 3 W, ~28-40 mm | |
| Capacitor 470 µF + 100 nF | perto do pino Vin do amplificador |

## Ligações (identicas no protótipo e na PCB)
| Sinal | Pino XIAO | GPIO | Vai para |
|---|---|---|---|
| 3V3 | 3V3 | - | Display VCC e **BLK** |
| GND | GND | - | Display GND, Amp GND |
| 5V | 5V | - | Amp Vin (+470 µF e 100 nF para GND) |
| SCK | D8 | 7 | Display SCL |
| MOSI | D10 | 9 | Display SDA |
| CS | D0 | 1 | Display CS |
| DC | D1 | 2 | Display DC |
| RST | D3 | 4 | Display RST |
| I2S DIN | D2 | 3 | Amp DIN |
| I2S BCLK | D4 | 5 | Amp BCLK |
| I2S LRC | D5 | 6 | Amp LRC |
| Alto-falante | - | - | saídas + e - do amplificador |

Amp **SD** e **GAIN**: deixe sem ligar (mono, ganho de 9 dB). Câmera e microfone usam pinos internos da Sense e não ocupam nenhum pino acima.

Cuidados:
- **Não insira cartão microSD** na Sense: o slot divide D8/D10 com o display.
- Alimentação pela USB-C. O pino 5V só tem tensão com USB conectado; se um dia usar bateria, o amplificador precisa ser alimentado pelo +BAT.
- Se a imagem da câmera sair de cabeça para baixo, é só inverter no firmware (`vflip`), depende de como você montar.

## PCB
**Não gerei o arquivo da PCB.** Não tenho KiCad aqui para rodar o DRC, e a ordem dos pinos do módulo do display e do MAX98357A muda de fabricante para fabricante. Uma PCB com a ordem errada não funciona (ou queima o módulo), e eu não quero te entregar um arquivo que parece pronto mas não foi validado.

O que já está decidido para a PCB (tabela de ligações acima é a netlist completa, 11 sinais):
- 2 camadas, 1,6 mm. Soquetes fêmea 2,54 mm para a XIAO (2x7, 15,24 mm entre as fileiras) e para o amplificador; o display em header 1x8.
- Trilhas de 3V3/5V/GND com pelo menos 0,5 mm; saída do alto-falante com 0,8 mm; plano de GND na camada de baixo.
- SPI curto (SCK/MOSI do display) e longe das trilhas do alto-falante.
- Capacitores 470 µF e 100 nF colados no Vin do amplificador.
- Orifício na caixa/PCB na frente da câmera e outro no microfone; alto-falante e amplificador do lado oposto ao microfone.

Para eu gerar o KiCad completo (esquemático + PCB + Gerbers) preciso de: o link ou a foto do módulo do display e do amplificador que você comprou, e se prefere a placa redonda atrás do display ou retangular.

## O que foi e o que não foi testado
Testado aqui (no PC, com o firmware compilado contra stubs do Arduino/ESP-IDF e conversando com o código Python real): compilação em `-std=gnu++11` sem avisos, protocolo serial (STATUS, TIME, RECORD, SNAP, PLAY e erros), rejeição de linhas inválidas, seleção do canal do microfone, ganho, duplicação estéreo do alto-falante, descanso após 30 s sem atividade, desenho do relógio (ponteiros conferidos nos pixels às 10:09:36).

**Não testado** (precisa da placa na sua mão):
- Compilação com o toolchain real do ESP32 (as assinaturas de `i2s_*`, `esp_camera_*` e `Serial.setRxBufferSize` foram escritas de memória do core Arduino-ESP32 2.0.17).
- Ganho do microfone (`MIC_GAIN = 4`), estalo no alto-falante, falhas de áudio durante a animação.
- Comportamento da USB nativa ao abrir a porta (a placa pode reiniciar; o console re-sincroniza o relógio depois).
- Voz no Windows (PowerShell) e no macOS; a chamada da API do Claude e o Whisper (sem rede aqui).
- Numerais 12/3/6/9 do relógio (no teste a fonte foi simulada por caixas).
